<?php
session_start();
require_once 'config/database.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Processar cancelamento de agendamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancelar'])) {
    $agendamento_id = filter_input(INPUT_POST, 'agendamento_id', FILTER_VALIDATE_INT);
    
    if ($agendamento_id) {
        try {
            $stmt = $pdo->prepare("UPDATE agendamentos SET status = 'cancelado' WHERE id = ? AND usuario_id = ?");
            $stmt->execute([$agendamento_id, $_SESSION['usuario_id']]);
            $_SESSION['mensagem'] = "Agendamento cancelado com sucesso!";
        } catch (PDOException $e) {
            $erro = "Erro ao cancelar o agendamento. Tente novamente.";
        }
    }
}

// Buscar agendamentos do usuário
$stmt = $pdo->prepare("
    SELECT a.*, s.nome as servico_nome, s.preco as servico_preco
    FROM agendamentos a
    JOIN servicos s ON a.servico_id = s.id
    WHERE a.usuario_id = ?
    ORDER BY a.data_agendamento DESC, a.hora_agendamento DESC
");
$stmt->execute([$_SESSION['usuario_id']]);
$agendamentos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Agendamentos - Barbearia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-cut"></i> Barbearia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="agendar.php">Agendar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="agendamentos.php">Meus Agendamentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Agendamentos -->
    <div class="container py-5">
        <h2 class="text-center mb-4">Meus Agendamentos</h2>
        
        <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php 
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($erro)): ?>
            <div class="alert alert-danger"><?php echo $erro; ?></div>
        <?php endif; ?>

        <?php if (empty($agendamentos)): ?>
            <div class="alert alert-info">
                Você ainda não possui agendamentos.
                <a href="agendar.php" class="alert-link">Clique aqui para agendar</a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($agendamentos as $agendamento): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100 fade-in">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($agendamento['servico_nome']); ?></h5>
                                <p class="card-text">
                                    <strong>Data:</strong> <?php echo date('d/m/Y', strtotime($agendamento['data_agendamento'])); ?><br>
                                    <strong>Horário:</strong> <?php echo date('H:i', strtotime($agendamento['hora_agendamento'])); ?><br>
                                    <strong>Valor:</strong> R$ <?php echo number_format($agendamento['servico_preco'], 2, ',', '.'); ?><br>
                                    <strong>Status:</strong> 
                                    <span class="badge bg-<?php 
                                        echo $agendamento['status'] == 'confirmado' ? 'success' : 
                                            ($agendamento['status'] == 'pendente' ? 'warning' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($agendamento['status']); ?>
                                    </span>
                                </p>
                                
                                <?php if ($agendamento['status'] == 'pendente'): ?>
                                    <form method="POST" action="" class="d-inline">
                                        <input type="hidden" name="agendamento_id" value="<?php echo $agendamento['id']; ?>">
                                        <button type="submit" name="cancelar" class="btn btn-danger" 
                                                onclick="return confirm('Tem certeza que deseja cancelar este agendamento?')">
                                            Cancelar Agendamento
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p><i class="fas fa-phone"></i> (11) 99999-9999</p>
                    <p><i class="fas fa-envelope"></i> contato@barbearia.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Horário de Funcionamento</h5>
                    <p>Segunda a Sexta: 9h às 20h</p>
                    <p>Sábado: 9h às 18h</p>
                    <p>Domingo: Fechado</p>
                </div>
                <div class="col-md-4">
                    <h5>Redes Sociais</h5>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 