<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'barbearia';
$username = 'root';
$password = '';

try {
    $mysqli = new mysqli($host, $username, $password, $dbname);
    if ($mysqli->connect_error) {
        throw new Exception("Erro de conexão: " . $mysqli->connect_error);
    }

    // Verificar estrutura da tabela
    $result = $mysqli->query("DESCRIBE agendamentos");
    $estrutura = [];
    while ($row = $result->fetch_assoc()) {
        $estrutura[] = $row;
    }

    // Verificar dados existentes
    $result = $mysqli->query("SELECT COUNT(*) as total FROM agendamentos");
    $total = $result->fetch_assoc()['total'];

    echo json_encode([
        'success' => true,
        'estrutura' => $estrutura,
        'total_agendamentos' => $total
    ]);

    $mysqli->close();
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 