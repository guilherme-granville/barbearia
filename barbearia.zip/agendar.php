<?php
session_start();
require_once 'config/database.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para agendar um horário.";
    $_SESSION['redirect_after_login'] = "agendar.php" . (isset($_GET['servico']) ? "?servico=" . $_GET['servico'] : "");
    header("Location: login.php");
    exit();
}

// Obter o serviço selecionado, se houver
$servico_selecionado = isset($_GET['servico']) ? (int)$_GET['servico'] : null;

// Buscar serviços disponíveis
try {
    $stmt = $pdo->prepare("SELECT id, nome, preco, duracao FROM servicos WHERE status = 1 ORDER BY nome");
    $stmt->execute();
    $servicos = $stmt->fetchAll();
} catch (PDOException $e) {
    $erro = "Erro ao carregar serviços. Tente novamente.";
}

// Processar o formulário de agendamento
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $servico_id = filter_input(INPUT_POST, 'servico', FILTER_VALIDATE_INT);
    $data = filter_input(INPUT_POST, 'data', FILTER_SANITIZE_STRING);
    $hora = filter_input(INPUT_POST, 'hora', FILTER_SANITIZE_STRING);

    if (empty($servico_id) || empty($data) || empty($hora)) {
        $erro = "Por favor, preencha todos os campos.";
    } else {
        try {
            // Verificar se o serviço existe e está ativo
            $stmt = $pdo->prepare("SELECT id, duracao FROM servicos WHERE id = ? AND status = 1");
            $stmt->execute([$servico_id]);
            $servico = $stmt->fetch();

            if (!$servico) {
                $erro = "Serviço inválido ou indisponível.";
            } else {
                // Verificar se a data é válida (não é domingo e está dentro do período permitido)
                $data_obj = new DateTime($data);
                $hoje = new DateTime();
                $max_data = (new DateTime())->modify('+14 days');

                if ($data_obj < $hoje) {
                    $erro = "A data selecionada é anterior a hoje.";
                } elseif ($data_obj > $max_data) {
                    $erro = "A data selecionada está muito distante. O agendamento deve ser feito com até 14 dias de antecedência.";
                } elseif ($data_obj->format('w') == 0) { // 0 = Domingo
                    $erro = "Não é possível agendar aos domingos.";
                } else {
                    // Verificar disponibilidade do horário
                    $data_hora = $data . ' ' . $hora;
                    $duracao = $servico['duracao'];
                    
                    // Calcular horário de término
                    $hora_fim = (new DateTime($data_hora))->modify("+{$duracao} minutes")->format('Y-m-d H:i:s');
                    
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) FROM agendamentos 
                        WHERE data_agendamento = ? 
                        AND (
                            (hora_agendamento <= ? AND ADDTIME(hora_agendamento, SEC_TO_TIME(duracao * 60)) > ?) 
                            OR (hora_agendamento < ? AND ADDTIME(hora_agendamento, SEC_TO_TIME(duracao * 60)) >= ?)
                        )
                        AND status != 'cancelado'
                    ");
                    $stmt->execute([$data, $hora, $hora, $hora_fim, $hora_fim]);
                    
                    if ($stmt->fetchColumn() > 0) {
                        $erro = "Horário indisponível. Por favor, escolha outro horário.";
                    } else {
                        // Verificar se já existe agendamento para o horário
                        $stmt = $pdo->prepare("
                            SELECT COUNT(*) 
                            FROM agendamentos 
                            WHERE data_agendamento = ? 
                            AND hora_agendamento = ? 
                            AND status != 'cancelado'
                        ");

                        $stmt->execute([$data, $hora]);
                        $agendamentos_encontrados = $stmt->fetchColumn();

                        if ($agendamentos_encontrados > 0) {
                            $_SESSION['erro'] = "Horário não disponível. Por favor, escolha outro horário.";
                            header("Location: agendar.php");
                            exit;
                        }

                        // Inserir o agendamento
                        $stmt = $pdo->prepare("
                            INSERT INTO agendamentos 
                            (usuario_id, servico_id, data_agendamento, hora_agendamento, status, created_at) 
                            VALUES (?, ?, ?, ?, 'confirmado', NOW())
                        ");

                        $stmt->execute([$_SESSION['usuario_id'], $servico_id, $data, $hora]);

                        $_SESSION['sucesso'] = "Agendamento realizado com sucesso!";
                        header("Location: meus_agendamentos.php");
                        exit;
                    }
                }
            }
        } catch (PDOException $e) {
            $erro = "Erro ao realizar agendamento. Tente novamente.";
        }
    }
}

// Gerar horários disponíveis
$horarios = [];
$inicio = new DateTime('09:00');
$fim = new DateTime('20:00');
$intervalo = new DateInterval('PT30M');

while ($inicio < $fim) {
    $horarios[] = $inicio->format('H:i');
    $inicio->add($intervalo);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Horário - Barbearia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .step {
            display: none;
        }
        .step.active {
            display: block;
        }
        .service-card {
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .service-card.selected {
            border: 2px solid #0d6efd;
        }
        .week-option {
            cursor: pointer;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .week-option:hover {
            background-color: #f8f9fa;
        }
        .week-option.selected {
            background-color: #e7f1ff;
            border-color: #0d6efd;
        }
        .time-slot {
            cursor: pointer;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .time-slot:hover {
            background-color: #f8f9fa;
        }
        .time-slot.selected {
            background-color: #e7f1ff;
            border-color: #0d6efd;
        }
        .time-slot.unavailable {
            background-color: #f8d7da;
            cursor: not-allowed;
            opacity: 0.7;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-cut"></i> Barbearia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="servicos.php">Serviços</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="agendar.php">Agendar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="agendamentos.php">Meus Horários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Agendamento Interativo -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow fade-in">
                    <div class="card-body">
                        <h2 class="text-center mb-4">Agendar Horário</h2>
                        
                        <?php if (isset($erro)): ?>
                            <div class="alert alert-danger"><?php echo $erro; ?></div>
                        <?php endif; ?>

                        <!-- Progresso -->
                        <div class="progress mb-4">
                            <div class="progress-bar" role="progressbar" style="width: 33%;" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100">Etapa 1</div>
                        </div>

                        <form method="POST" action="" id="formAgendamento">
                            <input type="hidden" name="servico" id="servico_selecionado">
                            <input type="hidden" name="data" id="data_selecionada">
                            <input type="hidden" name="hora" id="hora_selecionada">

                            <!-- Etapa 1: Seleção de Serviço -->
                            <div class="step active" id="step1">
                                <h4 class="mb-3">Selecione o Serviço</h4>
                                <div class="row">
                                    <?php foreach ($servicos as $servico): ?>
                                        <div class="col-md-6 mb-3">
                                            <div class="card service-card" data-id="<?php echo $servico['id']; ?>">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?php echo htmlspecialchars($servico['nome']); ?></h5>
                                                    <p class="card-text">
                                                        <strong>R$ <?php echo number_format($servico['preco'], 2, ',', '.'); ?></strong><br>
                                                        <small class="text-muted"><?php echo $servico['duracao']; ?> minutos</small>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="text-end mt-3">
                                    <button type="button" class="btn btn-primary" id="btnNext1" disabled>Avançar</button>
                                </div>
                            </div>

                            <!-- Etapa 2: Seleção de Dia -->
                            <div class="step" id="step2">
                                <h4 class="mb-3">Selecione o Dia</h4>
                                <div id="dias_disponiveis" class="row">
                                    <!-- Será preenchido via JavaScript -->
                                </div>
                                <div class="d-flex justify-content-between mt-3">
                                    <button type="button" class="btn btn-secondary" id="btnBack1">Voltar</button>
                                    <button type="button" class="btn btn-primary" id="btnNext2" disabled>Avançar</button>
                                </div>
                            </div>

                            <!-- Etapa 3: Seleção de Horário -->
                            <div class="step" id="step3">
                                <h4 class="mb-3">Selecione o Horário</h4>
                                <div id="horarios_disponiveis" class="row">
                                    <!-- Será preenchido via JavaScript -->
                                </div>
                                <div class="d-flex justify-content-between mt-3">
                                    <button type="button" class="btn btn-secondary" id="btnBack2">Voltar</button>
                                    <button type="submit" class="btn btn-success" id="btnConfirmar" disabled>Confirmar Agendamento</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p><i class="fas fa-phone"></i> (11) 99999-9999</p>
                    <p><i class="fas fa-envelope"></i> contato@barbearia.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Horário de Funcionamento</h5>
                    <p>Segunda a Sexta: 9h às 20h</p>
                    <p>Sábado: 9h às 18h</p>
                    <p>Domingo: Fechado</p>
                </div>
                <div class="col-md-4">
                    <h5>Redes Sociais</h5>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Variáveis globais
            let servicoSelecionado = null;
            let semanaSelecionada = null;
            let horarioSelecionado = null;
            let horariosDisponiveis = <?php echo json_encode($horarios); ?>;
            let servicoSelecionadoId = <?php echo $servico_selecionado ? $servico_selecionado : 'null'; ?>;

            // Funções de navegação
            function showStep(step) {
                document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
                document.getElementById('step' + step).classList.add('active');
                
                // Atualizar barra de progresso
                const progress = (step / 3) * 100;
                document.querySelector('.progress-bar').style.width = progress + '%';
                document.querySelector('.progress-bar').textContent = 'Etapa ' + step;
            }

            // Seleção de serviço
            document.querySelectorAll('.service-card').forEach(card => {
                card.addEventListener('click', function() {
                    document.querySelectorAll('.service-card').forEach(c => c.classList.remove('selected'));
                    this.classList.add('selected');
                    servicoSelecionado = this.dataset.id;
                    document.getElementById('servico_selecionado').value = servicoSelecionado;
                    document.getElementById('btnNext1').disabled = false;
                });
            });

            // Gerar dias disponíveis
            function gerarDias() {
                const container = document.getElementById('dias_disponiveis');
                container.innerHTML = '';
                
                const hoje = new Date();
                const maxData = new Date();
                maxData.setDate(hoje.getDate() + 14);
                
                let dataAtual = new Date(hoje);
                
                while (dataAtual <= maxData) {
                    // Pular domingos
                    if (dataAtual.getDay() !== 0) {
                        const col = document.createElement('div');
                        col.className = 'col-md-4 mb-3';
                        
                        const option = document.createElement('div');
                        option.className = 'week-option';
                        option.dataset.data = dataAtual.toISOString().split('T')[0];
                        
                        const formatter = new Intl.DateTimeFormat('pt-BR', { 
                            weekday: 'long',
                            day: '2-digit', 
                            month: '2-digit',
                            year: 'numeric'
                        });
                        
                        option.innerHTML = `
                            <div class="text-center">
                                <strong>${formatter.format(dataAtual)}</strong>
                            </div>
                        `;
                        
                        option.addEventListener('click', function() {
                            document.querySelectorAll('.week-option').forEach(o => o.classList.remove('selected'));
                            this.classList.add('selected');
                            semanaSelecionada = this.dataset.data;
                            document.getElementById('data_selecionada').value = semanaSelecionada;
                            document.getElementById('btnNext2').disabled = false;
                        });
                        
                        col.appendChild(option);
                        container.appendChild(col);
                    }
                    dataAtual.setDate(dataAtual.getDate() + 1);
                }
            }

            // Gerar horários disponíveis
            function gerarHorarios() {
                const container = document.getElementById('horarios_disponiveis');
                container.innerHTML = '';
                
                if (!semanaSelecionada) {
                    container.innerHTML = '<div class="col-12"><div class="alert alert-warning">Selecione um dia primeiro</div></div>';
                    return;
                }
                
                // Mostrar indicador de carregamento
                container.innerHTML = '<div class="col-12 text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Carregando...</span></div></div>';
                
                // Debug
                console.log("Verificando horários para o dia:", semanaSelecionada);
                console.log("Serviço selecionado:", servicoSelecionado);
                
                fetch(`verificar_horarios.php?data=${semanaSelecionada}&servico=${servicoSelecionado}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log("Resposta do servidor:", data);
                        
                        // Limpar o container
                        container.innerHTML = '';
                        
                        if (!data.success) {
                            container.innerHTML = `<div class="col-12"><div class="alert alert-danger">${data.message}</div></div>`;
                            return;
                        }
                        
                        if (data.horarios.length === 0) {
                            container.innerHTML = '<div class="col-12"><div class="alert alert-warning">Não há horários disponíveis para este dia. Por favor, selecione outro dia.</div></div>';
                            return;
                        }
                        
                        // Exibir horários disponíveis
                        data.horarios.forEach(horario => {
                            const col = document.createElement('div');
                            col.className = 'col-md-4 mb-2';
                            
                            const timeSlot = document.createElement('div');
                            timeSlot.className = 'time-slot';
                            timeSlot.textContent = horario;
                            timeSlot.dataset.hora = horario;
                            
                            timeSlot.addEventListener('click', function() {
                                document.querySelectorAll('.time-slot').forEach(t => t.classList.remove('selected'));
                                this.classList.add('selected');
                                horarioSelecionado = this.dataset.hora;
                                document.getElementById('hora_selecionada').value = horarioSelecionado;
                                document.getElementById('btnConfirmar').disabled = false;
                            });
                            
                            col.appendChild(timeSlot);
                            container.appendChild(col);
                        });
                    })
                    .catch(error => {
                        console.error('Erro ao verificar horários:', error);
                        container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Erro ao verificar horários disponíveis. Por favor, tente novamente.</div></div>';
                    });
            }

            // Event listeners para navegação
            document.getElementById('btnNext1').addEventListener('click', function() {
                if (servicoSelecionado) {
                    gerarDias();
                    showStep(2);
                }
            });

            document.getElementById('btnBack1').addEventListener('click', function() {
                showStep(1);
            });

            document.getElementById('btnNext2').addEventListener('click', function() {
                if (semanaSelecionada) {
                    gerarHorarios();
                    showStep(3);
                }
            });

            document.getElementById('btnBack2').addEventListener('click', function() {
                showStep(2);
            });

            // Pré-selecionar serviço se vier da página de serviços
            if (servicoSelecionadoId) {
                const card = document.querySelector(`.service-card[data-id="${servicoSelecionadoId}"]`);
                if (card) {
                    card.click();
                }
            }
        });
    </script>
</body>
</html> 