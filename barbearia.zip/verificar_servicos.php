<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'barbearia';
$username = 'root';
$password = '';

try {
    $mysqli = new mysqli($host, $username, $password, $dbname);
    if ($mysqli->connect_error) {
        throw new Exception("Erro de conexão: " . $mysqli->connect_error);
    }

    // Buscar todos os serviços
    $result = $mysqli->query("SELECT id, nome, duracao FROM servicos");
    $servicos = [];
    while ($row = $result->fetch_assoc()) {
        $servicos[] = $row;
    }

    echo json_encode([
        'success' => true,
        'servicos' => $servicos
    ]);

    $mysqli->close();
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 