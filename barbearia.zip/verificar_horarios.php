<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'barbearia';
$username = 'root';
$password = '';

try {
    $mysqli = new mysqli($host, $username, $password, $dbname);
    if ($mysqli->connect_error) {
        throw new Exception("Erro de conexão: " . $mysqli->connect_error);
    }

    $data = $_GET['data'] ?? '';
    $servico_id = $_GET['servico'] ?? '';

    if (empty($data) || empty($servico_id)) {
        throw new Exception("Data e serviço são obrigatórios");
    }

    // Verificar se a data é válida
    $data_obj = new DateTime($data);
    $hoje = new DateTime();
    $hoje->setTime(0, 0, 0);
    
    if ($data_obj < $hoje) {
        throw new Exception("Não é possível agendar para datas passadas");
    }

    // Verificar se o serviço existe
    $stmt = $mysqli->prepare("SELECT duracao FROM servicos WHERE id = ? AND status = 1");
    $stmt->bind_param("i", $servico_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $servico = $result->fetch_assoc();

    if (!$servico) {
        throw new Exception("Serviço não encontrado ou indisponível");
    }

    // Buscar horários ocupados
    $stmt = $mysqli->prepare("SELECT hora_agendamento FROM agendamentos WHERE data_agendamento = ? AND status != 'cancelado'");
    $stmt->bind_param("s", $data);
    $stmt->execute();
    $result = $stmt->get_result();
    $horarios_ocupados = [];
    while ($row = $result->fetch_assoc()) {
        $horarios_ocupados[] = $row['hora_agendamento'];
    }

    // Gerar horários disponíveis
    $horarios_disponiveis = [];
    $hora_inicio = strtotime('09:00');
    $hora_fim = strtotime('18:00');
    $duracao = $servico['duracao'] * 60; // Converter para segundos

    for ($hora = $hora_inicio; $hora < $hora_fim; $hora += $duracao) {
        $hora_formatada = date('H:i', $hora);
        if (!in_array($hora_formatada, $horarios_ocupados)) {
            $horarios_disponiveis[] = $hora_formatada;
        }
    }

    // Adicionar logs para debug
    error_log("Data: " . $data);
    error_log("Serviço ID: " . $servico_id);
    error_log("Duração do serviço: " . $servico['duracao']);
    error_log("Horários ocupados: " . implode(", ", $horarios_ocupados));
    error_log("Horários disponíveis: " . implode(", ", $horarios_disponiveis));

    echo json_encode([
        'success' => true,
        'horarios' => $horarios_disponiveis,
        'debug' => [
            'data' => $data,
            'servico_id' => $servico_id,
            'duracao' => $servico['duracao'],
            'horarios_ocupados' => $horarios_ocupados
        ]
    ]);

    $mysqli->close();
} catch (Exception $e) {
    error_log("Erro ao verificar horários: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 