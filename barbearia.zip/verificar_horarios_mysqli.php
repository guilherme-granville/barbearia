<?php
// Configurações do banco de dados
$host = 'localhost';
$dbname = 'barbearia';
$username = 'root';
$password = '';

header('Content-Type: application/json');

// Parâmetros
$data = filter_input(INPUT_GET, 'data', FILTER_SANITIZE_STRING);
$servico_id = filter_input(INPUT_GET, 'servico', FILTER_VALIDATE_INT);

// Log para debug
error_log("Verificando horários para: data=$data, servico=$servico_id");

if (!$data || !$servico_id) {
    echo json_encode(['erro' => 'Parâmetros inválidos']);
    exit;
}

try {
    // Conectar ao banco de dados usando PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Verificar se o serviço existe e está ativo
    $stmt = $pdo->prepare("SELECT id, nome, duracao FROM servicos WHERE id = ? AND status = 1");
    $stmt->execute([$servico_id]);
    $servico = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$servico) {
        echo json_encode(['erro' => 'Serviço inválido ou indisponível']);
        exit;
    }
    
    // Verificar se a data é válida
    $data_obj = new DateTime($data);
    $hoje = new DateTime();
    $hoje->setTime(0, 0, 0); // Resetar a hora para comparar apenas a data
    $max_data = (new DateTime())->modify('+14 days');
    $max_data->setTime(23, 59, 59);
    
    if ($data_obj < $hoje || $data_obj > $max_data || $data_obj->format('w') == 0) {
        echo json_encode(['erro' => 'Data inválida']);
        exit;
    }
    
    // Buscar agendamentos existentes para a data selecionada
    $stmt = $pdo->prepare("
        SELECT hora_agendamento, status 
        FROM agendamentos 
        WHERE data_agendamento = ? 
        AND status != 'cancelado'
    ");

    $stmt->execute([$data]);
    $horarios_ocupados = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Gerar horários disponíveis
    $horarios_disponiveis = [];
    $inicio = new DateTime($data . ' 09:00');
    $fim = new DateTime($data . ' 20:00');
    $intervalo = new DateInterval('PT30M');

    $horario = clone $inicio;
    while ($horario < $fim) {
        $horario_str = $horario->format('H:i');
        
        // Verificar se o horário está disponível
        $disponivel = !in_array($horario_str, $horarios_ocupados);
        
        $horarios_disponiveis[] = [
            'hora' => $horario_str,
            'disponivel' => $disponivel
        ];

        $horario->add($intervalo);
    }

    echo json_encode(['horarios' => $horarios_disponiveis]);
    
} catch (PDOException $e) {
    error_log("Erro ao verificar horários: " . $e->getMessage());
    echo json_encode(['erro' => 'Erro ao verificar horários']);
} 